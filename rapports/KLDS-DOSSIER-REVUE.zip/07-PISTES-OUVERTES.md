# 07 — Pistes ouvertes (et ce qu'il faut pour chacune)

Les 3 seules pistes non tranchées à la fin de la campagne. Chacune a un **script prêt** et une
**prouvabilité** claire. Le reste de la surface a été proved non exploitable (cf. `03-NOTE-DE-VERIFICATION.md`).

---

## P1 — Le correctif « password reset n'invalide pas les access tokens » tient-il ?

**Contexte.** Un rapport déjà accepté sur ce programme portait sur le fait qu'après une réinitialisation
de mot de passe, les access tokens déjà émis continuaient de fonctionner (~15 min de fenêtre d'écriture
résiduelle). Le correctif introduit un claim `epoch` (incrémenté au changement de mot de passe) ;
le token d'accès porte `epoch` et l'API le compare au compte.

**Constat de la campagne (à ne pas confondre).** L'`epoch` est resté à **0** dans les 7 jetons observés
(16:31 → 20:15). L'activation du 2FA invalide la session par un **autre** mécanisme (un état « 2FA
vérifiée » côté serveur), et l'access token ne porte **aucun** marqueur 2FA ni reset. Donc : rien ne
prouve encore que l'`epoch` s'incrémente au changement de mot de passe.

**Protocole (prêt).**
1. Obtenir un access token **frais, émis AVANT le reset** (via `/api/auth/session/refresh`).
2. Terminer la réinitialisation avec le token reçu par email → `resetPassword(token, newPassword)`
   (le `resetPassword` prend `newPassword: String!` + `token: String!`).
3. Tester l'access token de l'étape 1 sur `me`, `reports` et une écriture.
4. Re-mint un token (nouvel `epoch` ?) et re-tester la **session** navigateur (le `bounty-refresh`).

**Interprétation.**
| Résultat | Conclusion |
|---|---|
| l'access token **meurt** (et l'`epoch` passe à 1) | le correctif **tient** → à documenter comme « correctif vérifié » (valeur pour le programme) |
| l'access token **survit** | **2e rapport** : le correctif est incomplet → ATO post-récupération (**High**). Preuve : token émis avant → reset → token encore accepté sur une écriture |
| la session **survit** au reset | idem, mais en plus grave (une session survit au changement de mot de passe) |

**Donnée déjà collectée.** La **demande** de reset (sans même le changement) a **invalidé la session**
de l'expérimentateur (401 sur `/api/auth/session/refresh` juste après) → le mécanisme d'invalidation
existe bien côté session ; c'est le **token** qui reste à trancher.

**Coût pour le chercheur** : un token frais + l'accord pour fixer le mot de passe du compte de test
(`bb-test-2026!`), puis rien.

---

## P2 — Entropie des tokens envoyés par email

**Pourquoi c'est la voie ATO classique ici.** Tout ce qui passe par email (reset de mot de passe,
suppression du 2FA, invitation d'organisation) est un canal d'authentification. Si un de ces tokens est
court ou devinable → ATO.

**Déjà mesuré.** Le token de reset de mot de passe = **64 caractères hexadécimaux = 256 bits** (non
brutable). `forgotPassword` est **captcha-gated** (Turnstile + Private Access Token) **et** rate-limité
→ pas d'oracle d'énumération.

**Reste à mesurer** (mêmes tokens, canaux différents) :
- le token de **suppression du 2FA** (`removeTotpViaToken(token)` / `disableTotp(token)`) : est-il
  emailed avec la même robustesse, ou est-ce un code court ?
- le token d'**invitation d'organisation** (`acceptOrganizationInvitation`) : est-il emailed ? quelle
  entropie ? est-il lié à l'organisation et à l'email destinataire ?
- le token de **confirmation de changement d'email** (`confirmEmailChange(token)`).
- Le flux `requestEmailChange` exige `currentPassword` + `newEmail` et **refuse les adresses jetables**
  (« Disposable email addresses are not accepted ») → pour mesurer, il faut une adresse non jetable
  lisible par le chercheur (ex. une 2e adresse Gmail), ou faire transférer le mail reçu.

**Script** : `05-outils/reset-analysis.mjs` (mesure d'entropie, non destructive) + les formes exactes
des mutations relevées dans `03-NOTE-DE-VERIFICATION.md`.

---

## P3 — IDOR inter-comptes

**Pourquoi c'est le dernier angle non couvert.** Toutes les surfaces *lecture* ont été testées avec un seul
compte : le contrôle de propriété est vérifié partout (certificats, rapports, commentaires, transitions,
adjudication, appels, brouillons → `Unauthorized` ; `certificate(reference:)` répond `Unauthorized`
**pour toute référence, y compris inexistante** → pas d'énumération).

**Ce qu'il faut** : un **2e compte de test** (compte B). Protocole :
1. B soumet un rapport de test (ou le chercheur soumet avec A) → on récupère un **vrai** `reportId` de B.
2. A interroge `report(id)`, `reportComments`, `reportTransitions`, `reportAdjudication`,
   `reportAppeals`, `certificate(reference:)`, `downloadUrl(attachmentId:)` → si A lit le contenu de B →
   **IDOR (High)** ; si seul l'ID est exposé → fuite d'identifiant (Low/Medium).
3. Variante à tester en priorité : `organizationCertificates(orgId:)` et `get_org_report` (l'outil MCP
   `get_org_report` **ne vérifie pas localement** l'appartenance à l'org → il s'appuie sur l'API ; c'est
   le seul endroit où l'on s'appuie sur un contrôle distant).

**Limite assumée** : le programme n'autorise que les comptes de test du chercheur → il faut 2 comptes de
test, pas un compte réel.

---

## Ce qui n'est PAS une piste (pour éviter les impasses)

- **Le flux device-code (CLI)** : `createCliSignInCode` exige une session **2FA-vérifiée** → pas de
  downgrade ; et `exchangeCliSignInCode` est rate-limité.
- **Le `challengeToken` comme jeton d'accès** : refusé (audience `mfa-challenge` appliquée).
- **Le contournement WAF** : il fonctionne (3 payloads SQLi + 6 encodages de traversée) mais **aucun
  impact** derrière (clés UUID serveur, chemins validés côté application).
- **La forge de JWT** : le serveur utilise un JWKS figé et **ne suit pas** l'en-tête `jku` (0 requête
  observée côté OOB) → pas de SSRF via JWT.
- **Les sous-domaines** : `staging/beta/dev/…` résolvent (wildcard ELB) mais ne répondent pas.
