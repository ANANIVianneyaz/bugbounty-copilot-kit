# 00 — LISEZ-MOI (dossier de revue)

**Campagne** : bug bounty « KLDS — Web & API » (BugSecure Africa) · 2026-10-19 → 2026-10-20
**Chercheur** : compte de test unique (`william_root`, 2FA activé en fin de campagne)
**Objet de ce dossier** : 1 vulnérabilité soumise + la matrice de validation + les archives brutes,
pour **relecture critique indépendante** (relecture par un second modèle, « navette »).

> ⚠️ Contenu : ce dossier contient l'adresse email du compte de test du chercheur et l'IP de sortie de
> la plateforme (`52.214.90.218`, déjà présente dans le rapport soumis). Aucun jeton, cookie ou secret
> vivant n'y figure (expirés/révoqués, volontairement exclus).

---

## 1. Ce qui est dans le dossier

| Fichier | Rôle |
|---|---|
| `01-RAPPORT-SOUMISSION-SSRF-CIMD.md` | **Le rapport soumis** au programme, au format BugSecure (Titre/Description/Étapes/Impact/Sévérité/CVSS) |
| `02-RAPPORT-DE-MISSION.md` | Le compte rendu complet de campagne (méthode, finding, contrôles validés, hypothèses réfutées, pistes, livrables, leçons) |
| `03-NOTE-DE-VERIFICATION.md` | La matrice de validation (~45 contrôles prouvés non exploitables, chacun avec sa preuve) |
| `04-pieces/` | Les 8 pièces jointes du rapport (dont la capture PNG du log de réception et la capture 302 verbatim) |
| `05-outils/` | Les 19 scripts de la campagne (moteur d'auto-réparation GraphQL, matrices WAF, tests MFA, etc.) + leur README |
| `06-journaux/` | Les journaux bruts (200+ traces de requêtes) + un manifeste qui mappe chaque fichier aux contrôles qu'il prouve |
| `07-PISTES-OUVERTES.md` | Les 3 pistes restantes, avec ce qu'il faut et ce que chacune prouverait |

---

## 2. Le finding en 5 lignes

**SSRF non authentifié sur le serveur d'autorisation OAuth** (CWE-918), via le mécanisme
*Client ID Metadata Document* : `GET /oauth/authorize?client_id=<URL>` fait **fetch serveur de l'URL
fournie**, sans authentification, sans inscription, sans quota, **depuis l'infrastructure de la
plateforme**, et **analyse la réponse** pour en déduire l'identité du client (nom, `redirect_uris`,
`grant_types`, `scope`) → oracle binaire sur la cible atteinte.

- **CVSS** : `AV:N/AC:L/PR:N/UI:N/S:U/C:L/I:N/A:N` → **5.3 (Medium)**
- **Preuve** : 44 requêtes sortantes capturées côté chercheur (chemin unique par essai), UA
  `BugSecure-OAuth/1 (+client-id-metadata-document)`, IP source `52.214.90.218` (AWS), + capture 302
  verbatim (`location: …/oauth/consent?request=…`) horodatée à la seconde.
- **Limites mesurées et assumées** : filtre d'IP efficace (loopback, RFC1918, `169.254.169.254` écartés,
  y compris par nom DNS, IPv4-mapped IPv6, NAT64 `64:ff9b:1::/48`) ; redirections **non** suivies ;
  certificat TLS distant **validé** ; usurpation de nom de client refusée sur les deux chemins.
- **Écart de conception relevé** : le chemin CIMD contourne l'inscription (donc le quota) et le filtrage
  du `scope` du chemin DCR.

---

## 3. Mes 5 questions pour la relecture (c'est l'intérêt de la navette)

1. **La sévérité est-elle bien calibrée ?** L'impact démontré est un relais GET externe sans quota depuis
   l'IP de la plateforme, avec un oracle binaire sur la cible. Un triage peut vouloir High (relais
   depuis une IP de confiance, amplifier l'impact) ou Low (aveu de SSRF aveugle, pas de lecture).
   **Quel argument manquait-il pour défendre 5.3 ?** Et comment formuler la « voie d'escalade » pour que
   le triage la considère sans qu'on surcale rien ?
2. **Le périmètre réseau du fetch est-il correctement décrit ?** J'ai mesuré par le **minimum** de 5
   échantillons (le bruit de file d'attente domine). Y a-t-il une méthode plus fiable pour démontrer
   (ou infirmer) l'atteinte d'un service interne via le CIMD, sans disposer d'un callback interne ?
3. **Le chemin CIMD ouvre-t-il d'autres vecteurs que je n'ai pas testés ?** (RFC 9207 `iss`, RFC 8707
   `resource` multiple, OIDC PAR `request_uri`/`request`, `client_id` en URL avec `redirect_uri` implicite,
   `authorization_details`/RAR, DPoP, `private_key_jwt`, `client_secret_basic` vs `none`, mTLS, JWT
   client authentication, `token_introspection`, `device_authorization`.) Lesquels pourraient combiner
   avec le fetch pour escalader l'impact ?
4. **Le contrôle anti-usurpation d'identité de client est-il réellement、初初初hole-proof ?** Il refuse
   `BugSecure`, `BugSecure Africa`, `SSO BugSecure`, `Senintel BugSecure`, `MCP Bugsecure officiel`,
   `bugsecure-mcp` — sur les deux chemins. **Quelles variantes d'échappement du filtre n'ai-je pas
   essayées** (homoglyphes Unicode, espaces insécables, casse composée, caractères de contrôle,
   zero-width, bidi, marques de bidi, etc.) ? Et le filtre est-il une liste de sous-chaînes (donc
   contournable par `BugSecureX`/`XBugSecure`/`)BugSecure(`) ?
5. **Quelle est la meilleure piste restante pour un 2e rapport de classe High ?** Les 3 pistes ouvertes
   (invalidation de l'access token au reset de mot de passe ; entropie des tokens envoyés par email ;
   IDOR inter-comptes) — laquelle a le meilleur rapport impact/effort, et **quels payloads
   supplémentaires** faut-il tenter pour chacune ?

---

## 4. Ce qui a été ruled out (pour ne pas re-perdre de temps)

45 contrôles vérifiés et prouvés non exploitables, dont : forge de JWT (`jku`/`x5u`/`jwk`/HS256 — le JWKS
est figé, le `jku` n'est **jamais** fetché) · SQLi (5 surfaces + différentiels booléens → paramétré) ·
PKCE (S256 obligatoire, pas de downgrade, pas d'omission) · `redirect_uri` (comparaison exacte) ·
`scope`/`resource` non dupliquables · `iss` toujours émis par l'AS · `prompt=none` et `request_uri`
(RFC 9101) non implémentés · code d'autorisation single-use · refresh token à rotation stricte avec
révocation de famille · token-exchange et `client_credentials` refusés · **7 patterns MFA/2FA clos**
(aucun jeton avant la 2FA, `challengeToken` inutilisable comme jeton d'accès, pas d'oracle de préfixe,
rate-limit ~3-4/60 s) · énumération de certificats impossible (`Unauthorized` uniforme) · uploads (clé
UUID serveur) · XSS stocké (la bio est rendue en texte React) · SSRF `/_next/image` (allowlist) ·
`avatarUrl` (aucun fetch serveur) · CORS / host-header / session fixation / instance de staging.

---

## 5. Comment je veux la relecture

Trois questions prioritaires, dans cet ordre :
1. **la sévérité** (est-ce que 5.3 se défend ?),
2. **la complétude des techniques OAuth testées** (question 3 ci-dessus),
3. **les payloads à essayer en priorité** sur les 3 pistes ouvertes (question 5).

Le reste (méthode, tableaux de validation, journaux) est là pour que tu puisses **vérifier mes
affirmations** plutôt que les croire : chaque ligne de `03-NOTE-DE-VERIFICATION.md` renvoie à un
fichier de `06-journaux/`.
